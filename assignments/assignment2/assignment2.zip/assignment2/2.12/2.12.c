/* intAndFloat.c
 * Using printf to display an integer and a float.
 * 2017-09-29: Bob Plantz
 */
#include <stdio.h>

int main(void)
{
  int anInt = 19088743;
  float aFloat = 19088.743;

  printf("The integer is %d and the float is %f\n", anInt, aFloat);

  return 0;
}